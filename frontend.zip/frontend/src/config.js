const app_config={
    apiurl:"http://localhost:5000"
}

export default app_config;