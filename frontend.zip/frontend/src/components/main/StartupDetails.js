import React from 'react'

const StartupDetails = () => {

    

  return (
    <div>StartupDetails</div>
  )
}

export default StartupDetails