
const api_config = {
    PORT : 5000,
    DB_URL : 'mongodb+srv://shitigopal:1234@cluster0.mplv5.mongodb.net/StartupFunding?retryWrites=true&w=majority'
}

module.exports = api_config;